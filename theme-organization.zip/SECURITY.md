# 安全说明

## 报告安全问题

如发现安全漏洞，请通过仓库 Issues 进行反馈：

- https://github.com/bi1kbu/halo-themes-org/issues

如需补充私下联系渠道，请告知维护者更新本文件。
